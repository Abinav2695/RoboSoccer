#!/bin/bash
# These are the packages required for install on Arch Linux systems.
sudo pacman -Sy gcc qt5-base eigen protobuf libdc1394 cmake v4l-utils jsoncpp
