#!/bin/bash

# These are the packages required on Ubuntu systems.
apt-get install -qq g++ qtdeclarative5-dev libeigen3-dev protobuf-compiler libprotobuf-dev libdc1394-22 libdc1394-22-dev cmake libv4l-0 libopencv-dev freeglut3-dev
